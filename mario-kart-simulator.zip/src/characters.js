
const characters = {
    Mario: { baseSpeed: 5 },
    Luigi: { baseSpeed: 5 },
    Peach: { baseSpeed: 6 },
    Yoshi: { baseSpeed: 6 },
    Bowser: { baseSpeed: 4 },
    Toad: { baseSpeed: 7 }
};

module.exports = characters;
